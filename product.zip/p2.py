def solution(a):
  return a / 8